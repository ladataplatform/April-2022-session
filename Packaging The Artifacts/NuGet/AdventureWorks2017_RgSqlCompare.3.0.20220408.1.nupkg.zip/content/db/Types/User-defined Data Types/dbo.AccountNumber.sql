CREATE TYPE [dbo].[AccountNumber] FROM nvarchar (15) NULL
GO
