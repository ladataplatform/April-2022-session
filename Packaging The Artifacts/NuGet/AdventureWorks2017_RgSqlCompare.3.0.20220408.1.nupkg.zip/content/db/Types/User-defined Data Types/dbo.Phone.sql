CREATE TYPE [dbo].[Phone] FROM nvarchar (25) NULL
GO
