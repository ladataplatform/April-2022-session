EXEC sp_addextendedproperty N'MS_Description', N'AdventureWorks 2016 Sample OLTP Database', NULL, NULL, NULL, NULL, NULL, NULL
GO
